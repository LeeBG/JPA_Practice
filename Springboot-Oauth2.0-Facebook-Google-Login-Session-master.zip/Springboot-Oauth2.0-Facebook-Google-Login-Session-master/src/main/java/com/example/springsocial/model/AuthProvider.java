package com.example.springsocial.model;

public enum AuthProvider {
    local,
    facebook,
    google
}
